// import logo from './logo.svg';
// import './App.css';

import Header from "./Component/Header/Header"
import Navbar from "./Component/Navbar/Navbar";
import Categories from "./Component/Categories/Categories";
import Home from "./Component/Home/Home"
import TopCategories from "./Component/TopCategories/TopCategories";
import PopularProducts from "./Component/PopularProducts/PopularProducts";
import Footer from "./Component/Footer/Footer"

function App() {
  return (
    <div className="App">
        <Header/>
        <Categories/>
        <Navbar/>
        <Home/>
        <TopCategories/>
        <PopularProducts/>
        <Footer/>
    </div>
  );
}

export default App;
