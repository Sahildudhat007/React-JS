import React from 'react'

import '../Categories/categories.css'

const Categories = () => {
  return (
    <div>
      
      <div className='container mx-auto px-5 mt-5'>
        <button className='cat-btn'>
          <i class="fa-solid fa-bars mr-3"></i>
          Categories
        </button>
      </div>

        

    </div>
  )
}

export default Categories

